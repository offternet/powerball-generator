#!/bin/bash

fkey=$(($RANDOM * $$))

export iconsDir="/home/yadbash/powerball/icons"

yad2 --on-top  --undecorated --width=100 --height=80  --center --no-buttons --html --disable-search --user-style=URI --uri="/home/yadbash/powerball/source/gif.html" & 

sleep 5

killall yad2
