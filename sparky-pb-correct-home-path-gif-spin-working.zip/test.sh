#!/bin/bash

fkey=$(($RANDOM * $$))

export iconsDir="/opt/yadbash/powerball/icons"

# yad --plug="$fkey" --tabnum=1 --html --disable-search --user-style=URI --uri="/opt/yadbash/powerball/source/gif.html" &

yad --plug="$fkey" --tabnum=1 --icons --read-dir="/opt/yadbash/powerball/icon-gif" --monitor --item-width=100 --sort-by-name &

yad \
        --title="HELLO WORLD YADPAGE" \
	--plug="$fkey" \
	--tabnum=2 \
	--icons --read-dir="$iconsDir/display" --monitor --single-click --item-width=80 --sort-by-name  &

yad \
        --title="HELLO WORLD YADPAGE" \
	--paned \
	--key="$fkey" \
    --splitter=100 \
	--width=800 \
	--height=275 \
	--title="$title" \
	--center 
