#!/bin/bash
# File: /home/yadbash/powerball/sparkypowerball.sh
# Author: Bobby Cooper - http://YadBash.com/ based on work by Yad Author, Victor Ananjevsky
# (c) 2018-2019 Licensed Under GPL 2.1

export mainDir="/home/yadbash/powerball" 
export iconsDir="/home/yadbash/powerball/icons"
export listDir="/home/yadbash/powerball/list"
export imagesDir="/home/yadbash/powerball/images"
export sourceDir="/home/yadbash/powerball/source"
export tempDir="/home/yadbash/powerball/temp"
export iconHoldDir="/home/yadbash/powerball/temp/ahold-icon"

title="Sparky Powerball - By Offternet - Bobby Cooper"

winIcon="imagesDir/sparkypb.png"

cd $iconsDir/display/
	rm *.desktop >> null

rm $iconHoldDir/*.desktop

fkey=$(($RANDOM * $$))
cd $mainDir 

if [ ! -d "$tempDir" ]; then
  mkdir /home/yadbash/powerball/temp
fi

sleep 2

cd $mainDir/icons/reset
	cp *.desktop $iconsDir/display


enter_keyNumber() {
. /$sourceDir/enter-keynumber.source
}
export -f enter_keyNumber

about_yadbash() { 
. /$sourceDir/info_yadbash.source
}
export -f about_yadbash

current_numbers() {
. /$sourceDir/display-window-export-save-prnt.source
}
export -f current_numbers

gen_pbNumbers() {
cd $iconsDir/display/
	rm *.desktop >> null
. /$sourceDir/generate-pb-5numbers-1pb.source
}
export -f gen_pbNumbers

pb_reset() {
	rm $iconsDir/display/*.desktop >> null
	rm $iconHoldDir/*.desktop >> null

sleep 2

cd $iconsDir/reset
	cp *.desktop $iconsDir/display
}
export -f pb_reset 


yad --plug="$fkey" --form --tabnum=1 --columns=1 \
 	--image="/home/yadbash/powerball/images/sparky-pb-800-banner-icon.png"  \
	--column="Name" \
	--expand-column=1 &


yad \
	--plug="$fkey" \
	--tabnum=2 \
	--icons --read-dir="$iconsDir/display" --monitor --single-click --item-width=80 --sort-by-name  &

yad \
	--paned \
	--key="$fkey" \
    --splitter=110\
	--width=900 \
	--height=300 \
	--title="$title" \
	--window-icon="$winIcon"  \
	--center  \
    --button="Get Numbers":"bash -c gen_pbNumbers" \
	--button="About YadBash":"bash -c about_yadbash" \
	--button="Key Number":"bash -c enter_keyNumber" \
	--button="Numbers":"bash -c current_numbers"  \
	--button="Reset":"bash -c pb_reset" \
	--button="Exit":1

	ret=$?
	[[ $ret -eq 1 ]] && exit

	exit
